<!doctype html>
<html>
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title>Gooberlicious - web design in Cheltenham UK</title>
<meta name="description" content="Gooberlicious is the online portfolio of digital creative, Joe Baldwin. Joe has many years experience in webdesign and digital marketing. From website design and production to entire webbanner and email marketing campaigns." />
<meta name="generator" content="concrete5 - 5.6.2.1" />
<script type="text/javascript">
var CCM_DISPATCHER_FILENAME = '/index.php';var CCM_CID = 1;var CCM_EDIT_MODE = false;var CCM_ARRANGE_MODE = false;var CCM_IMAGE_PATH = "/updates/concrete5.6.2.1_updater/concrete/images";
var CCM_TOOLS_PATH = "/index.php/tools/required";
var CCM_BASE_URL = "http://gooberlicious.co.uk";
var CCM_REL = "";

</script>

	<link rel="shortcut icon" href="/files/3813/9984/1711/favicon.ico" type="image/x-icon" />
	<link rel="icon" href="/files/3813/9984/1711/favicon.ico" type="image/x-icon" />
	<link rel="apple-touch-icon" href="/files/4013/9984/1785/ifavicon.png"  />
<link rel="stylesheet" type="text/css" href="/updates/concrete5.6.2.1_updater/concrete/css/ccm.base.css?v=05eaf14507e355e5fd24f5e5a33fc18d" />
<script type="text/javascript" src="/updates/concrete5.6.2.1_updater/concrete/js/jquery.js?v=05eaf14507e355e5fd24f5e5a33fc18d"></script>
<script type="text/javascript" src="/updates/concrete5.6.2.1_updater/concrete/js/ccm.base.js?v=05eaf14507e355e5fd24f5e5a33fc18d"></script>
<style type="text/css"> 
#blockStyle63Main2Layout1Cell122 {background-repeat:no-repeat; margin: 40px 0;} 
#blockStyle75Main328 {background-repeat:no-repeat; color: #899A92;float: left;width: 300px;margin-left: 200px;position:relative;} 
#blockStyle103Main329 {background-repeat:no-repeat; color: #899A92;float: right;width: 300px;margin-right: 200px;position:relative;} 
#areaStyleMain34 {background-repeat:no-repeat; } 
#areaStyleMain423 {background-repeat:no-repeat; } 
#areaStyleMain524 {background-repeat:no-repeat; } 
#areaStyleMain625 {background-repeat:no-repeat; } 
</style>
<link rel="stylesheet" type="text/css" href="/blocks/page_list/templates/portfolio/view.css?v=05eaf14507e355e5fd24f5e5a33fc18d" />
<meta property="og:title" content="This is Gooberlicious">
<meta property="og:url" content="http://www.gooberlicious.co.uk/">
<meta property="og:type" content="portfolio">
<meta property="og:description" content="Gooberlicious is the online portfolio of web designer Joe Baldwin">
<meta property="og:type" content="website">
<meta property="og:image" content="http://gooberlicious.co.uk/files/5615/0447/0249/fb-og.jpg"><meta name="viewport" content="width=device-width; initial-scale=0.7">
<link href="/themes/gooberlicious/css/normalize.css" rel="stylesheet" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Asap:400,400italic,700,700italic|Amatic+SC:400,700' rel='stylesheet' type='text/css'>
<link href="/themes/gooberlicious/css/goo.css" rel="stylesheet" type="text/css" media="screen">
<link href="/themes/gooberlicious/css/goo_mobile.css" rel="stylesheet" type="text/css" media="screen and (max-width: 700px)">
<link rel="stylesheet" type="text/css" href="/js/lightview/css/lightview/lightview.css"/>
</head>

<body>

<div id="divWrapper" class="">
		<div id="divTitle" class="clearfix">
			<img border="0" class="ccm-image-block" alt="Gooberlicious - Your ideal partner in digital design and development" src="/files/1013/9156/3485/logo.png" width="473" height="221" />        </div>
		
        <div id="divHeader" class="rowWrapper clearfix">
			<iframe src="/elements/shooting_gallery/index.html" marginheight="0" marginwidth="0" align="center" scrolling="no" frameborder="0" name="" width="100%" height="575">
  your browser does not support iframes!
</iframe>

        </div><!-- #divMain1 -->
        
        <div id="divMain1" class="rowWrapper odd clearfix">
        	<div class="row">
			<div id="ccm-layout-wrapper-221" class="ccm-layout-wrapper"><div id="ccm-layout-main1-2-1" class="ccm-layout ccm-layout-table  ccm-layout-name-Main1-Layout-1 "><div class="ccm-layout-row ccm-layout-row-1"><div class="ccm-layout-2-col-1 ccm-layout-cell ccm-layout-col ccm-layout-col-1 first" style="width:100%"><h1>This is Gooberlicious</h1>
<p>Hello, my name is Joe Baldwin, I'm a digital designer and web developer based in the UK. Gooberlicious is my online portfolio space.</p>
<p>With a background in commercial art and over 15 year's experience in web development I have the skills and attention to detail to bring your project to life. I speak fluent ‘Art Director’ and ‘IT Engineer’ enabling me to translate any idea into great digital work.</p>
<p>I'm also a part-time rock star and occasionally find time to paint, draw and create original font designs (find me on <a href="https://www.t26.com/search?q=joe+baldwin">T26.com</a>)</p></div><div class="ccm-spacer"></div></div></div></div><div id="ccm-layout-wrapper-222" class="ccm-layout-wrapper"><div id="ccm-layout-main1-3-2" class="ccm-layout ccm-layout-table  ccm-layout-name-Main1-Layout-2 "><div class="ccm-layout-row ccm-layout-row-1"><div class="ccm-layout-3-col-1 ccm-layout-cell ccm-layout-col ccm-layout-col-1 first" style="width:33%"><h2>Design skills</h2>
<ul>
<li>Illustration (traditional and digital)</li>
<li>Animation (Flash, HTML and video)</li>
<li>Web design</li>
<li>Print design</li>
<li>Branding</li>
</ul></div><div class="ccm-layout-3-col-2 ccm-layout-cell ccm-layout-col ccm-layout-col-2 " style="width:33%"><h2>Development skills</h2>
<ul>
<li>HTML production</li>
<li>Javascript and jQuery</li>
<li>PHP development</li>
<li>CMS deployment</li>
<li>Wordpress blogs and site-builds</li>
<li>Facebook apps</li>
</ul></div><div class="ccm-layout-3-col-3 ccm-layout-cell ccm-layout-col ccm-layout-col-3 last" style="width:33.99%">&nbsp;</div><div class="ccm-spacer"></div></div></div></div>            </div><!-- .row -->
        </div><!-- #divMain1 -->
        
        <div id="divMain2" class="rowWrapper even clearfix">
        	<div class="arrow"></div>
        	<div class="row">
			<div id="ccm-layout-wrapper-223" class="ccm-layout-wrapper"><div id="ccm-layout-main2-5-1" class="ccm-layout ccm-layout-table  ccm-layout-name-Main2-Layout-1 "><div class="ccm-layout-row ccm-layout-row-1"><div class="ccm-layout-5-col-1 ccm-layout-cell ccm-layout-col ccm-layout-col-1 first" style="width:100%"><h1>Clients and projects</h1>
<p>I've been a freelancer in one way or another since 1993 aside from a five year stint with Ogilvy (even then I was running my own Web development company in the evenings). In that time I've built up a considerable body of work and some very happy clients.</p>
<p>I enjoy the challenges of working for small local businesses as much as blue chip clients and global ad agencies.</p>	<div id="blockStyle63Main2Layout1Cell122" class="equiSpaceImages ccm-block-styles" >
<p><img class="scale" title="DHL" src="/files/6713/9116/3866/client_dhl.png" alt="client_dhl.png" width="84" height="47" /> <img class="scale" title="Warner Bros." src="/files/3113/9116/3867/client_wb.png" alt="client_wb.png" width="43" height="47" /> <img class="scale" title="Yahoo!" src="/files/1613/9116/3867/client_yahoo.png" alt="client_yahoo.png" width="99" height="47" /> <img class="scale" title="Fidelity Investments" src="/files/3613/9116/3867/client_fidelity.png" alt="client_fidelity.png" width="99" height="47" /> <img class="scale" title="JP Morgan" src="/files/4613/9116/3867/client_jpmorgan.png" alt="client_jpmorgan.png" width="102" height="47" /> <img class="scale" title="AXA" src="/files/9413/9116/3866/client_axa.png" alt="client_axa.png" width="47" height="47" /> <img class="scale" title="Momentum Films" src="/files/8713/9116/3867/client_momentum.png" alt="client_momentum.png" width="119" height="47" /> <img class="scale" title="BAA" src="/files/2413/9116/3866/client_baa.png" alt="client_baa.png" width="112" height="47" /> <img class="scale" title="Bayer" src="/files/5813/9116/3866/client_bayer.png" alt="client_bayer.png" width="47" height="47" /></p></div></div><div class="ccm-spacer"></div></div></div></div><div id="ccm-layout-wrapper-224" class="ccm-layout-wrapper"><div id="ccm-layout-main2-4-2" class="ccm-layout ccm-layout-table  ccm-layout-name-Main2-Layout-2 "><div class="ccm-layout-row ccm-layout-row-1"><div class="ccm-layout-4-col-1 ccm-layout-cell ccm-layout-col ccm-layout-col-1 first" style="width:100%">
<div class="ccm-page-list">

			<div class="project-item clearfix">
            <div class="project-thumbnail"><a href="/amplified/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720"><img src="/files/1814/9911/6182/amplified-cover.jpg" width="405>" height="305" alt="" /></a></div>
            <h2 class="ccm-page-list-title">
                <a href="/amplified/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720">Amplified</a>
            </h2>
            <p class="project-description">
                <p>Site design and production for Amplified Open Air Festival. The project involved the site design and development, online marketing efforts, newsletter design and e-mailouts. The site is built using Concrete5 CMS for simple WYSIWYG editing.</p>            </p>
            <p class="project-tags">
                                    <span>HTML/CSS</span> 
                                    <span>CMS</span> 
                                    <span>PHP programming</span> 
                                    <span>eMail marketing</span> 
                                    <span>Design</span> 
                                    <span>jQuery</span> 
                                    <span>HTML5</span> 
                  
            </p>
            <p class="project-url">
                <a href="http://amplifiedrocks.com/" class="newWindow">amplifiedrocks.com/</a>
            </p>
		</div>
			<div class="project-item clearfix">
            <div class="project-thumbnail"><a href="/geoff-senior/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720"><img src="/files/1914/9911/6159/geoffsenior-cover.jpg" width="405>" height="305" alt="" /></a></div>
            <h2 class="ccm-page-list-title">
                <a href="/geoff-senior/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720">Geoff Senior</a>
            </h2>
            <p class="project-description">
                <p>Geoff Senior required a new site to showcase his comic-book illustration and fine art. The design is responsive using Bootstrap and Concrete5 CMS for easy updates and a user-friendly experience on all devices.</p>            </p>
            <p class="project-tags">
                                    <span>HTML/CSS</span> 
                                    <span>CMS</span> 
                                    <span>PHP programming</span> 
                                    <span>Design</span> 
                                    <span>jQuery</span> 
                                    <span>HTML5</span> 
                  
            </p>
            <p class="project-url">
                <a href="http://geoffsenior.com/" class="newWindow">geoffsenior.com/</a>
            </p>
		</div>
			<div class="project-item clearfix">
            <div class="project-thumbnail"><a href="/treehouse24/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720"><img src="/files/8414/7748/9645/treehouse_thumbnail.jpg" width="405>" height="305" alt="" /></a></div>
            <h2 class="ccm-page-list-title">
                <a href="/treehouse24/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720">Treehouse24</a>
            </h2>
            <p class="project-description">
                <p>Treehouse24 are a pre-production visualising, storyboarding, animatic and animation studio for the advertising industry. This CMS-based site is touchscreen-friendly and delivers a range of multimedia content in a creative and intuitive design.</p>            </p>
            <p class="project-tags">
                                    <span>HTML/CSS</span> 
                                    <span>CMS</span> 
                                    <span>PHP programming</span> 
                                    <span>jQuery</span> 
                                    <span>HTML5</span> 
                  
            </p>
            <p class="project-url">
                <a href="http://treehouse24.co.uk/" class="newWindow">treehouse24.co.uk/</a>
            </p>
		</div>
			<div class="project-item clearfix">
            <div class="project-thumbnail"><a href="/peacock-tree-ecology/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720"><img src="/files/4614/7792/5749/peacock2016_thumb.jpg" width="405>" height="305" alt="" /></a></div>
            <h2 class="ccm-page-list-title">
                <a href="/peacock-tree-ecology/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720">Peacock Tree Ecology</a>
            </h2>
            <p class="project-description">
                <p>I was recommended to Peacock Tree Ecology, by another client, to redesign an under-performing site. I redesigned and rebuilt the site to focus on client-needs and SEO. It's based on a fantastic WYSIWYG CMS that makes updates quick and easy. I also set up social media and a blog which they have taken to like pros! Since the update there has been a significant increase in enquiries.</p>            </p>
            <p class="project-tags">
                                    <span>HTML/CSS</span> 
                                    <span>CMS</span> 
                                    <span>PHP programming</span> 
                                    <span>eMail marketing</span> 
                                    <span>Design</span> 
                                    <span>jQuery</span> 
                                    <span>Blog</span> 
                                    <span>SEO</span> 
                  
            </p>
            <p class="project-url">
                <a href="http://www.peacock-tree-ecology.co.uk/" class="newWindow">www.peacock-tree-ecology.co.uk/</a>
            </p>
		</div>
			<div class="project-item clearfix">
            <div class="project-thumbnail"><a href="/yahoo-movie-trailer-generator/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720"><img src="/files/3313/9748/7064/thumbnail_yahoo_movie.jpg" width="405>" height="305" alt="" /></a></div>
            <h2 class="ccm-page-list-title">
                <a href="/yahoo-movie-trailer-generator/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720">Yahoo Movie Trailer Generator</a>
            </h2>
            <p class="project-description">
                <p>Working with designs from OgilvyOne I developed this fun Flash app for Yahoo Movies. Using a clever drag and drop interface and some nifty audio sample sequencing you can record and share your own creative movie trailers. Traffic was generated by a condensed form of the app running in a banner on IMDB.</p>            </p>
            <p class="project-tags">
                                    <span>PHP programming</span> 
                                    <span>Flash banners</span> 
                                    <span>Flash programming</span> 
                                    <span>mySQL</span> 
                  
            </p>
            <p class="project-url">
                <a href="" class="newWindow"></a>
            </p>
		</div>
			<div class="project-item clearfix">
            <div class="project-thumbnail"><a href="/leon-harrocks/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720"><img src="/files/9714/1053/1763/thumbnail_leonharrocks.jpg" width="405>" height="305" alt="" /></a></div>
            <h2 class="ccm-page-list-title">
                <a href="/leon-harrocks/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720">Leon Harrocks</a>
            </h2>
            <p class="project-description">
                <p>This portfolio site for talented designer Leon Harrocks features a CMS for easy updates and responsive design for optimised display on desktops, tablets and mobiles.</p>            </p>
            <p class="project-tags">
                                    <span>HTML/CSS</span> 
                                    <span>CMS</span> 
                                    <span>Javascript</span> 
                                    <span>jQuery</span> 
                                    <span>Responsive design</span> 
                  
            </p>
            <p class="project-url">
                <a href="http://leonharrocks.com" class="newWindow">leonharrocks.com</a>
            </p>
		</div>
			<div class="project-item clearfix">
            <div class="project-thumbnail"><a href="/simon-amstell/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720"><img src="/files/7913/9202/4334/thumbnail_simonamstell.jpg" width="405>" height="305" alt="" /></a></div>
            <h2 class="ccm-page-list-title">
                <a href="/simon-amstell/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720">Simon Amstell</a>
            </h2>
            <p class="project-description">
                <p>This site for actor and comedian Simon Amstell was built using a WYSIWYG CMS system to enable quick updates with minimum training.</p>            </p>
            <p class="project-tags">
                                    <span>HTML/CSS</span> 
                                    <span>CMS</span> 
                                    <span>PHP programming</span> 
                  
            </p>
            <p class="project-url">
                <a href="" class="newWindow"></a>
            </p>
		</div>
			<div class="project-item clearfix">
            <div class="project-thumbnail"><a href="/mojo-brand-development/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720"><img src="/files/3713/9756/1333/thumbnail_mojo.jpg" width="405>" height="305" alt="" /></a></div>
            <h2 class="ccm-page-list-title">
                <a href="/mojo-brand-development/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720">Mojo Brand Development</a>
            </h2>
            <p class="project-description">
                <p>I had previously worked with Mike Owen and Jon Chandler when they headed BrandHealth International. I developed the original website and helped with all digital marketing communications. When they struck out on their own with Mojo Brand Development they asked me to do the same. The site is CMS based and includes a growing blog-styled article repository.</p>            </p>
            <p class="project-tags">
                                    <span>HTML/CSS</span> 
                                    <span>CMS</span> 
                                    <span>Javascript</span> 
                                    <span>eMail marketing</span> 
                                    <span>Design</span> 
                  
            </p>
            <p class="project-url">
                <a href="http://www.mojobd.com" class="newWindow">www.mojobd.com</a>
            </p>
		</div>
			<div class="project-item clearfix">
            <div class="project-thumbnail"><a href="/bayer-crop-science/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720"><img src="/files/7514/7749/2494/bayer_thumbnail.jpg" width="405>" height="305" alt="" /></a></div>
            <h2 class="ccm-page-list-title">
                <a href="/bayer-crop-science/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720">Bayer Crop Science</a>
            </h2>
            <p class="project-description">
                <p>I have art directed and produced a huge amount of online advertising for Bayer Crop Science including HTML5 banner advertising campaigns, eMail marketing, microsites and website updates. </p>            </p>
            <p class="project-tags">
                                    <span>HTML/CSS</span> 
                                    <span>Javascript</span> 
                                    <span>eMail marketing</span> 
                                    <span>jQuery</span> 
                                    <span>Banner advertising</span> 
                  
            </p>
            <p class="project-url">
                <a href="" class="newWindow"></a>
            </p>
		</div>
			<div class="project-item clearfix">
            <div class="project-thumbnail"><a href="/red-box-recorders/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720"><img src="/files/2513/9117/1063/thumbnail_redbox.jpg" width="405>" height="305" alt="" /></a></div>
            <h2 class="ccm-page-list-title">
                <a href="/red-box-recorders/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720">Red Box Recorders</a>
            </h2>
            <p class="project-description">
                <p>I worked closely with HiveB2B to deliver all aspects of digital work for this voice and data recording solutions provider. Work included rich media banners, email marketing and web development as part of a broader integrated campaign.</p>
<p class="newWindow">The Red Box Recorders website was redesigned using a CMS framework that allows WYSIWYG editing and a private ‘partner area’ that alerts global partners to the latest downloadable software updates and information.</p>            </p>
            <p class="project-tags">
                                    <span>HTML/CSS</span> 
                                    <span>CMS</span> 
                                    <span>Javascript</span> 
                                    <span>eMail marketing</span> 
                                    <span>Flash banners</span> 
                  
            </p>
            <p class="project-url">
                <a href="" class="newWindow"></a>
            </p>
		</div>
			<div class="project-item clearfix">
            <div class="project-thumbnail"><a href="/eden-health-and-beauty-spa/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720"><img src="/files/9913/9964/4082/thumbnail_eden.jpg" width="405>" height="305" alt="" /></a></div>
            <h2 class="ccm-page-list-title">
                <a href="/eden-health-and-beauty-spa/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720">Eden Health And Beauty Spa</a>
            </h2>
            <p class="project-description">
                <p>I designed and built this simple HTML site for a local beauty salon. In addition, I set up social media, started an e-newsletter and optimised their Google presence to ensure they were getting maximum online exposure.</p>            </p>
            <p class="project-tags">
                                    <span>HTML/CSS</span> 
                                    <span>Javascript</span> 
                                    <span>PHP programming</span> 
                                    <span>Design</span> 
                  
            </p>
            <p class="project-url">
                <a href="http://edenhealthandbeautyspa.co.uk/" class="newWindow">edenhealthandbeautyspa.co.uk/</a>
            </p>
		</div>
			<div class="project-item clearfix">
            <div class="project-thumbnail"><a href="/tiger-wishing-tree/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720"><img src="/files/6313/9964/6238/thumbnail_tigerwishing.jpg" width="405>" height="305" alt="" /></a></div>
            <h2 class="ccm-page-list-title">
                <a href="/tiger-wishing-tree/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720">Tiger Wishing Tree</a>
            </h2>
            <p class="project-description">
                <p>This cute Flash game was designed and built for Tiger Beer to celebrate Chinese New Year. I was responsible for the Illustration and styling as well as animation. I programmed the PHP and mySQL back-end and Flash front-end for the competition elements. One of my very talented suppliers provided the game engine.</p>            </p>
            <p class="project-tags">
                                    <span>HTML/CSS</span> 
                                    <span>PHP programming</span> 
                                    <span>Animation</span> 
                                    <span>Flash programming</span> 
                                    <span>mySQL</span> 
                                    <span>Illustration</span> 
                  
            </p>
            <p class="project-url">
                <a href="" class="newWindow"></a>
            </p>
		</div>
			<div class="project-item clearfix">
            <div class="project-thumbnail"><a href="/brand-culture/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720"><img src="/files/1413/9179/5530/thumbnail_brandculture.jpg" width="405>" height="305" alt="" /></a></div>
            <h2 class="ccm-page-list-title">
                <a href="/brand-culture/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720">Brand Culture Sport & Entertainment</a>
            </h2>
            <p class="project-description">
                <p>Brand Culture approached me to build a fresh web presence with the focus on fresh blog content. I built the site using a WYSIWYG CMS system that makes updates a breeze and looks fantastic. The project also included jQuery enhancements and some iPad-friendly HTML animation.</p>            </p>
            <p class="project-tags">
                                    <span>HTML/CSS</span> 
                                    <span>CMS</span> 
                                    <span>Javascript</span> 
                                    <span>PHP programming</span> 
                                    <span>Animation</span> 
                  
            </p>
            <p class="project-url">
                <a href="" class="newWindow"></a>
            </p>
		</div>
			<div class="project-item clearfix">
            <div class="project-thumbnail"><a href="/blissful-childcare/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720"><img src="/files/9514/1053/4034/thumbnail_blissful.jpg" width="405>" height="305" alt="" /></a></div>
            <h2 class="ccm-page-list-title">
                <a href="/blissful-childcare/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720">Blissful Childcare</a>
            </h2>
            <p class="project-description">
                <p>Blissful Childcare provide mobile childcare services for corporate events and weddings. I designed the identity and produced printed collateral and a new website. A playful design was chosen with a single-page responsive design.</p>            </p>
            <p class="project-tags">
                                    <span>HTML/CSS</span> 
                                    <span>CMS</span> 
                                    <span>Javascript</span> 
                                    <span>Design</span> 
                                    <span>jQuery</span> 
                                    <span>Responsive design</span> 
                  
            </p>
            <p class="project-url">
                <a href="http://blissfulcildcare.co.uk" class="newWindow">blissfulcildcare.co.uk</a>
            </p>
		</div>
			<div class="project-item clearfix">
            <div class="project-thumbnail"><a href="/repunkd/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720"><img src="/files/8417/2541/3717/gooberlicious-thumbnail-repunkd.png" width="405>" height="305" alt="" /></a></div>
            <h2 class="ccm-page-list-title">
                <a href="/repunkd/" class="lightview" data-lightview-type="iframe" data-lightview-group-options="skin:'light',width:900,height:720">rePunK’d</a>
            </h2>
            <p class="project-description">
                <p>A punky anti-design website for this punk rock and new wave revival show.</p>            </p>
            <p class="project-tags">
                                    <span>CMS</span> 
                                    <span>Design</span> 
                  
            </p>
            <p class="project-url">
                <a href="https://re-punkd.band" class="newWindow">https://re-punkd.band</a>
            </p>
		</div>
	 

	 
</div><!-- end .ccm-page-list -->


</div><div class="ccm-spacer"></div></div></div></div>            </div><!-- .row -->
        </div><!-- #divMain2 -->
        
        <div id="divMain3" class="rowWrapper odd clearfix">
        	<div class="arrow"></div>
            <div class="row">
				<div id="areaStyleMain34" class="altColors contact ccm-area-styles ccm-area-styles-a18" >
<h1>Contact</h1>
<p>If you like what you've seen and would like to see more or have a project that you’d like to discuss please contact me by email or phone.</p>	<div id="blockStyle75Main328" class="email_icon ccm-block-styles" >
<p style="text-align: center;"><a href="mailto:joe.baldwin@gooberlicious.co.uk"><img title="Email:" src="/files/3813/9178/9984/icon_email.png" alt="icon_email.jpg" width="110" height="110" /></a></p>
<p style="text-align: center;"><a href="mailto:joe.baldwin@gooberlicious.co.uk">joe.baldwin@gooberlicious.co.uk</a></p></div>	<div id="blockStyle103Main329" class="mobile_icon ccm-block-styles" >
<p style="text-align: center;"><img title="Phone:" src="/files/7313/9178/9973/icon_mobile.png" alt="icon_mobile.jpg" width="110" height="110" /></p>
<p style="text-align: center;">07547 217 538</p></div></div>            </div><!-- .row -->
        </div><!-- #divMain3 -->
        
        <div id="divMain4" class="rowWrapper even clearfix">
        	<div class="arrow"></div>
            <div class="row">
				<div id="areaStyleMain423" class="hide ccm-area-styles ccm-area-styles-a19" >
</div>            </div><!-- .row -->
        </div><!-- #divMain4 -->
        
        <div id="divMain5" class="rowWrapper odd clearfix">
        	<div class="arrow"></div>
            <div class="row">
				<div id="areaStyleMain524" class="hide ccm-area-styles ccm-area-styles-a20" >
</div>            </div><!-- .row -->
        </div><!-- #divMain5 -->
        
        <div id="divMain6" class="rowWrapper even clearfix">
        	<div class="arrow"></div>
            <div class="row">
				<div id="areaStyleMain625" class="hide ccm-area-styles ccm-area-styles-a21" >
</div>            </div><!-- .row -->
        </div><!-- #divMain6 -->

    <div id="divFooter" class="rowWrapper clearfix">
    	<div class="row">
        <p>Joe Baldwin © 2026</p>
        </div><!-- .row -->
    </div><!-- #divFooter -->
</div>
<script type="text/javascript" src="/js/lightview/js/spinners/spinners.min.js"></script>
<script type="text/javascript" src="/js/lightview/js/lightview/lightview.js"></script>
<script type='text/javascript' src='/js/lightview/js/lightview/lightview-custom-skin.js'></script>
<script type='text/javascript'>
  Lightview.setDefaultSkin('mac');
</script>

<script src="http://cdnjs.cloudflare.com/ajax/libs/gsap/latest/TweenMax.min.js"></script>
<script src="/js/superscrollorama/js/jquery.superscrollorama.js"></script>
<script type="text/javascript" src="/themes/gooberlicious/js/goo.js"></script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-50875245-1', 'gooberlicious.co.uk');
  ga('send', 'pageview');
ga(‘set’, ‘&uid’, {{USER_ID}}); // Set the user ID using signed-in user_id.

</script></body>
</html>
